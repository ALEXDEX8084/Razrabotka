﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace testprog1_msp
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void countbtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                double a = double.Parse(txb1.Text);
                double b = double.Parse(txb2.Text);
                string s = Convert.ToString(a + b);
                string r = Convert.ToString(a - b);
                string m = Convert.ToString(a * b);
                string c = Convert.ToString(a / b);
                Summa.Text = s;
                rasnost.Text = r;
                multipl.Text = m;
                chastn.Text = c;

                StreamWriter sw = new StreamWriter("Result.txt", true, Encoding.UTF8);
                sw.WriteLine($"Исходные данные: {txb1.Text}; {txb1.Text} Результат: {Summa.Text}; {rasnost.Text}; {multipl.Text}; {chastn.Text}");
                sw.Close();
            }
            catch
            {
                MessageBox.Show("Введите числа", "Неверный ввод данных", MessageBoxButton.OK, MessageBoxImage.Error);
            }

        }
    }
}
